from env.game import GoBangGame
from env.game import WHITE
from env.graphics import *
from agents.alpha_beta import AlphaBetaAgent

import random


class GoBangEnv(GoBangGame):
    

    def __init__(self, board_size=15, render=False, internal_agent=None):
        super(GoBangEnv, self).__init__(board_size)
        
        if internal_agent is None:
            self.internal_agent = AlphaBetaAgent(WHITE, weak=True)
        else:
            self.internal_agent = internal_agent
        self.render = render
        self.reset()  

    def reset(self):
        
        if hasattr(self, 'window'):
            self.window.close()

        if self.render:
            w = self.board_width * 40
            h = self.board_height * 40
            window = GraphWin("this is a gobang env", w, h)
            window.setBackground("yellow")
            for i in range(0, w + 40, 40):
                line = Line(Point(i, 0), Point(i, w))
                line.draw(window)
            for i in range(0, h + 40, 40):
                line = Line(Point(0, i), Point(h, i))
                line.draw(window)
            self.window = window

        super(GoBangEnv, self)._reset()
        if random.random() < 0.5:  
            self.take(self.internal_agent.choose_action(self),
                self.internal_agent.role, False, None, True, False)
        return self.board.copy()

    def step(self, action, player=None, show=False, color=None, strict=True, debug=False):
        
        if not self.check_action(action):
            next_board = self.board.copy()
            done = True
            reward = -0.9
            return next_board, reward, done, None

        self.take(action, player, show, color, strict, debug)
        if self.game_over(show=show, debug=debug):
            next_board = self.board.copy()
            reward = self.reward(player)
            done = True
            return next_board, reward, done, None

        internal_action = self.internal_agent.choose_action(self)
        self.take(internal_action, self.internal_agent.role, show, color, strict, debug)
        next_board = self.board.copy()
        reward = self.reward(player)
        done = self.game_over(show, debug)
        return next_board, reward, done, None

    def reward(self, player):
        
        winner = self.winner()
        if winner == player:
            return 1
        elif winner == -player:
            return -1
        else:
            return 0


if __name__ == '__main__':
    pass
