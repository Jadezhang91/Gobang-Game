from env.graphics import *

import numpy as np

WHITE = 1
BLACK = -1
EMPTY = 0
DRAW = 0
COLOR = {WHITE: 'white', BLACK: 'black', DRAW: 'draw'}
DX = (1, 0, 1, 1)
DY = (0, 1, 1, -1)


class GoBangGame(object):
    

    def __init__(self, board_size=15):
        
        if isinstance(board_size, int):
            self.board_width = board_size
            self.board_height = board_size
        elif isinstance(board_size, tuple):
            assert len(board_size) == 2
            self.board_height, self.board_width = board_size
        else:
            assert False

        self._reset()

    def _reset(self):
        
        self.prev_player = None  
        self.prev_actions = []  
        self.board = np.zeros((self.board_height, self.board_width), dtype=np.int32)  # 棋盘
        self._legal_actions = set()  
        for x in range(self.board_width):
            for y in range(self.board_height):
                self._legal_actions.add((x, y))  

        self.prev_pieces = []

    def take(self, action, role=WHITE, show=False, color=None, strict=True, debug=False):
        # print(self.prev_player, role, action)
        
        if isinstance(action, int):
            _x = action // self.board_height
            _y = action % self.board_height
            action = (_x, _y)

        if debug:
            print('step', role)
        if strict:
            assert self.prev_player != role, (self.prev_player, role)
        self.check_action(action)
        if show:
            piece = Circle(Point(40 * action[0], 40 * action[1]), 16)
            piece.setFill(COLOR[role] if color is None else color)
            piece.draw(self.window)
            self.prev_pieces.append(piece)

        self.prev_player = role
        self.prev_actions.append(action)
        self._legal_actions.remove(action)  
        self.board[action] = role  

    def back(self, show=False, strict=True, debug=False):
        
        if debug:
            print('back', self.prev_player)

        self._legal_actions.add(self.prev_actions[-1])
        self.board[self.prev_actions[-1]] = EMPTY
        self.prev_actions.pop(-1)

        if strict:
            self.prev_player = WHITE if self.prev_player == BLACK else BLACK

        if show:
            self.prev_pieces[-1].undraw()
            self.prev_pieces.pop(-1)

    def is_winner(self, player, action):
        
        if self.prev_player is None:
            return False

        for k in range(4):
            p1, p2 = 0, 0
            x = action[0] + DX[k]
            y = action[1] + DY[k]
            while self.in_board(x, y) and player == self.board[x, y]:
                x += DX[k]
                y += DY[k]
                p1 += 1
            x = action[0] - DX[k]
            y = action[1] - DY[k]
            while self.in_board(x, y) and player == self.board[x, y]:
                x -= DX[k]
                y -= DY[k]
                p2 += 1

            if p1 + p2 >= 4:
                return True

        return False

    def in_board(self, x, y):
        return 0 <= x < self.board_width and 0 <= y < self.board_height

    def winner(self):
        
        if self.prev_actions and self.is_winner(self.prev_player, self.prev_actions[-1]):
            return self.prev_player
        if len(self._legal_actions) == 0:
            return DRAW
        return None

    def game_over(self, show, debug=True):
        
        winner = self.winner()
        if winner is not None:
            if debug:
                if winner is DRAW:
                    msg = "The game ends with draw."
                else:
                    msg = f"The winner is {COLOR[winner]}."

                if show:
                    message = Text(Point(100, 100), msg)
                    message.draw(self.window)
                    self.window.getMouse()
                    self.window.close()
            return True
        return False

    def check_action(self, action):
        
        if isinstance(action, int):
            _x = action // self.board_height
            _y = action % self.board_height
            action = (_x, _y)

        return action in self._legal_actions

    def legal_actions(self):
        return self._legal_actions

    def _check_action(self, action, show):
        if not self.check_action(action):
            if show:
                message = Text(Point(200, 200), f"invalid action: {action}.")
                message.draw(self.window)
            else:
                print(f"invalid action: {action}.")

            return False

        return True

    def play(self, player1, player2, show):
        
        if show:  
            w = self.board_width * 40
            h = self.board_height * 40
            window = GraphWin("this is a gobang env", w, h)
            window.setBackground("yellow")
            for i in range(0, w + 40, 40):
                line = Line(Point(i, 0), Point(i, w))
                line.draw(window)
            for i in range(0, h + 40, 40):
                line = Line(Point(0, i), Point(h, i))
                line.draw(window)
            self.window = window

        cur_player = player1
        while True:
            action = cur_player.choose_action(self)  
            if not self._check_action(action, show):  
                break
            self.take(action, cur_player.role, show)  
            if self.game_over(show):  
                return self.winner()

           
            if cur_player == player1:
                cur_player = player2
            else:
                cur_player = player1


if __name__ == '__main__':
    game = GoBangGame()
