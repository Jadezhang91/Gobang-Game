import random
import torch
import time
import torch.nn as nn
import numpy as np
import os

from agents.dqn import DQNAgent
from env.environment import GoBangEnv
from env.game import BLACK

seed = 2019


def set_random_seed(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)


replay_cfg = dict(
    size=500,
    batch_size=64,
    learn_start=64
)

render = False
num_episodes = 10000000
env = GoBangEnv(15, render)
num_actions = 15 * 15
set_random_seed(seed)
use_cuda = torch.cuda.is_available()


def train():
    
    cfg = dict(role=BLACK, eps_greedy=0.9, gamma=0.95, lr=1e-3)
    agent = DQNAgent(**cfg)
    resume_ep = 0
    # agent.load_model(resume_ep)
    start_time = time.time()
    for ep in range(num_episodes):
        ep += resume_ep
        env.reset()
        max_steps = 113
        total_reward = 0
        for t in range(max_steps):
            state = np.expand_dims(env.board, 0)
            action = agent.choose_action(env)
            next_state, reward, done, info = env.step(action, BLACK, show=render)
            experience = (state, action, reward, np.expand_dims(next_state, 0), done)
            agent.store_transition(experience)
            total_reward += reward
            loss = agent.update()

            if done or t + 1 == max_steps:
                agent.writer.add_scalar('live1/finish_step', t, global_step=ep)
                agent.writer.add_scalar('live1/reward', total_reward, global_step=ep)
                if ep % 10 == 0:
                    print("episodes {}, used time is {:.2f}s, finish step is {}, reward is {:.2f}, "
                          "loss is {:.3f} ".format(ep, time.time() - start_time, t, total_reward, loss))
                break
        if ep % 2000 == 0 or ep + 1 == num_episodes:
            agent.save_model(ep)


if __name__ == '__main__':
    train()
