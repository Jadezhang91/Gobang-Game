import numpy as np


class Memory(object):
    

    def __init__(self, size=10000, batch_size=256, learn_start=1000):
        self.learn_start = learn_start
        self.size = size
        self.batch_size = batch_size
        self.count = 0
        self._memory = [None] * self.size

    def store_transition(self, transition):
        ind = self.count % self.size
        self._memory[ind] = transition
        self.count += 1

    def sample(self):
        num_items = min(self.count, self.size)
        inds = np.array(list(range(num_items)))
        np.random.shuffle(inds)
        sample_inds = inds[:self.batch_size]

        return [self._memory[i] for i in sample_inds]

    def is_ok(self):
        return self.count >= self.learn_start


if __name__ == '__main__':
    m = Memory(20, 5, 5)

    for i in range(1000):
        m.store_transition(i)

        if m.is_ok():
            print(m.sample())
        else:
            print("wait")
