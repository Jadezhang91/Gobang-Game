from env.game import GoBangGame
from agents.human_player import HumanAgent
from agents.alpha_beta import AlphaBetaAgent
from agents.random_agent import RandomAgent

import argparse

WHITE = 1
BLACK = -1


def arg_parse():
    parser = argparse.ArgumentParser()
    parser.add_argument('--p1', default='alphabeta', help='type of player 1')
    parser.add_argument('--p2', default='human', help='type of player 2')
    parser.add_argument('--d', default=1, type=int, help='max depth of alphabeta agent')
    parser.add_argument('--n', default=1, type=int, help='number of rounds')
    parser.add_argument('--show', default=True, type=bool, help='whether to show the game board')
    return parser.parse_args()


args = arg_parse()


def get_agent(p, color):
    if p == 'alphabeta':
        return AlphaBetaAgent(role=color, max_depth=args.d)
    elif p == 'human':
        return HumanAgent(role=color)
    elif p == 'random':
        return RandomAgent(role=color)
    else:
        raise ValueError("Only support alphabeta, human and random agent.")


def run():
    for i in range(args.n):
        p1 = get_agent(args.p1, BLACK)
        p2 = get_agent(args.p2, WHITE)
        game = GoBangGame()
        winner = game.play(p1, p2, args.show)
        print(f"The {i+1}th game: ", end='')
        if winner == WHITE:
            print(f"winner is {args.p1}")
        elif winner == BLACK:
            print(f"winner is {args.p2}")
        else:
            print('draw')


if __name__ == '__main__':
    run()
