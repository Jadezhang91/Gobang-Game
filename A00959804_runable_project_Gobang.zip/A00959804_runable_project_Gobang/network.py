import torch
import torch.nn as nn
from torch.nn import functional as F


class QNetwork(nn.Module):
    

    def __init__(self, num_actions=2, in_channels=1):
        super(QNetwork, self).__init__()
        self.relu = nn.ReLU(inplace=True)
        self.conv1 = nn.Conv2d(in_channels, 8, 3, 1, padding=1)
        self.conv2 = nn.Conv2d(8, 16, 3, 1, padding=1)
        self.fc = nn.Linear(15 * 15 * 16, 512)
        self.out = nn.Linear(512, num_actions)

    def forward(self, x):
        x = self.relu(self.conv1(x))
        x = self.relu(self.conv2(x))
        x = x.view(x.size(0), -1)
        x = self.relu(self.fc(x))

        return self.out(x)
