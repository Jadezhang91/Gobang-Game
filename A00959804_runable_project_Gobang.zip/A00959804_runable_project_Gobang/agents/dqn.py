import random
import torch
import time
import torch.nn as nn
import numpy as np
import os
from agents.agent import Agent
from network import QNetwork
from torch.optim import Adam
from tensorboardX import SummaryWriter
from experience_replay import Memory

num_actions = 15 * 15
use_cuda = torch.cuda.is_available()

replay_cfg = dict(
    size=500,
    batch_size=64,
    learn_start=64
)


class DQNAgent(Agent):
    

    def __init__(self, role, gamma, lr, eps_greedy=1, resume=None):
        super(DQNAgent, self).__init__(role=role)
        self._exp_replay = Memory(**replay_cfg)  
        self.targetQ = QNetwork(num_actions)
        self.actorQ = QNetwork(num_actions)
        self.actorQ.load_state_dict(self.targetQ.state_dict())

        if use_cuda:
            print("Use cuda...")
            self.actorQ.cuda()
            self.targetQ.cuda()

        self._mse_loss = nn.MSELoss()

        self.eps_greedy = eps_greedy
        self.gamma = gamma

        self.optimizer = Adam(self.actorQ.parameters(), lr)
        self.update_count = 0
        self.writer = SummaryWriter('./DQN/logs')

        if resume:
            self.load_model(resume)

    def get_loss(self, actor_values, target_values):
        return self._mse_loss(actor_values, target_values)

    def store_transition(self, transition):
        """
        存放经验
        """
        assert isinstance(transition, tuple)
        self._exp_replay.store_transition(transition)

    def choose_action(self, game):
        
        if random.random() > self.eps_greedy:  
            x, y = random.choice(list(game.legal_actions()))
            action = x * game.board_height + y
        else:
            state = np.expand_dims(game.board, 0)
            state = torch.tensor(state, dtype=torch.float).unsqueeze(0)
            if use_cuda:
                state = state.cuda()
            state_values = self.actorQ(state)  
            legal_actions = torch.tensor([a[0] * game.board_height + a[1] for a in game.legal_actions()],
                dtype=torch.long, device=state.device) 
            state_values = state_values[0][legal_actions]  
            max_value, arg_max = torch.max(state_values, 0)  
            action = legal_actions[arg_max].item()

        return action

    def _ensemble(self, experiences):
        
        states = torch.tensor([e[0] for e in experiences], dtype=torch.float)
        actions = torch.tensor([e[1] for e in experiences], dtype=torch.long)
        rewards = torch.tensor([e[2] for e in experiences], dtype=torch.float)
        next_states = torch.tensor([e[3] for e in experiences], dtype=torch.float)
        done_mask = torch.tensor([e[4] for e in experiences], dtype=torch.float)

        if use_cuda:
            return states.cuda(), actions.cuda(), rewards.cuda(), next_states.cuda(), done_mask.cuda()
        return states, actions, rewards, next_states, done_mask

    def update(self):
        
        if self._exp_replay.is_ok(): 
            experiences = self._exp_replay.sample()  
            states, actions, rewards, next_states, done_mask = self._ensemble(experiences)
            with torch.no_grad():
                next_max_Q = self.targetQ(next_states).max(1)[0]
                next_max_Q = (1 - done_mask) * next_max_Q
                target_values = rewards + self.gamma * next_max_Q  

            actor_values = self.actorQ(states).gather(1, actions.unsqueeze(1))
            loss = self.get_loss(actor_values, target_values.unsqueeze(1))  
            self.optimizer.zero_grad()
            loss.backward()
            self.optimizer.step()  
            self.writer.add_scalar('loss1/value_loss', loss, self.update_count)  
            self.update_count += 1
            if self.update_count % 100 == 0:  
                self.targetQ.load_state_dict(self.actorQ.state_dict())
            return loss.item()
        return 0

    def save_model(self, global_step):
        
        if not os.path.exists('./workdir1/DQN/'):
            os.makedirs('./workdir1/DQN/')
        torch.save(self.targetQ.state_dict(), f'./workdir1/DQN/target_epoch_{global_step}.pth')
        torch.save(self.actorQ.state_dict(), f'./workdir1/DQN/actor_epoch_{global_step}.pth')

    def load_model(self, global_step):
        
        sd1 = torch.load(f'./workdir1/DQN/target_epoch_{global_step}.pth', map_location='cpu')
        sd2 = torch.load(f'./workdir1/DQN/actor_epoch_{global_step}.pth', map_location='cpu')
        self.targetQ.load_state_dict(sd1)
        self.actorQ.load_state_dict(sd2)

        if use_cuda:
            self.targetQ.cuda()
            self.actorQ.cuda()
