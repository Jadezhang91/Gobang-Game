
class Agent(object):
    def __init__(self, role):
        self.role = role

    def choose_action(self, *args, **kwargs):
        raise NotImplementedError()
