from agents.agent import Agent


class HumanAgent(Agent):
    def __init__(self, role):
        super(HumanAgent, self).__init__(role)

    def choose_action(self, game):
        while True:
            point = game.window.getMouse()
            x, y = round((point.getX()) / 40), round((point.getY()) / 40)
            if game.check_action((x, y)):
                return x, y
