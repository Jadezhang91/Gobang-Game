
import math
import random

from agents.agent import Agent
from env.game import GoBangGame


DX = (1, 0, 1, 1)
DY = (0, 1, 1, -1)
WHITE = 1
BLACK = -1
EMPTY = 0
W = WHITE
B = BLACK
E = EMPTY


active2 = ['?AA?']  
active3 = ['?AAA?']  
active4 = ['?AAAA?'] 
five = ['AAAAA'] 

blocked2 = ['?AA', 'AA?']  
blocked3 = ['?AAA', 'AAA?']  
blocked4A = ['?AAAA', 'AAAA?']  
blocked4B = ['A?AAA', 'AAA?A']  
blocked4C = ['AA?AA']  


def jump(x, y, dx, dy, stride, game):
    
    x += dx * stride
    y += dy * stride

    return None if not game.in_board(x, y) else game.board[x, y]


def get_line(x, y, orientation, strides, game, player):
    
    dx = DX[orientation]
    dy = DY[orientation]
    line = [jump(x, y, dx, dy, stride, game) for stride in strides]
    line = ['A' if it == player else ('?' if it == EMPTY else 'B') for it in line]  # 处理棋子，使其与player匹配
    return ''.join(line)  


def is_matching(patterns, line):
    
    return any(line.find(pat) != -1 for pat in patterns)


def has_neighbours(pos, game):
    
    for k in range(4):
        to = jump(pos[0], pos[1], DX[k], DY[k], 1, game)
        if to is not None and to != EMPTY:
            return True

        to = jump(pos[0], pos[1], DX[k], DY[k], -1, game)
        if to is not None and to != EMPTY:
            return True

    return False


def get_opponent(me):
    return -me


def get_opponent_color(color):
    return 'red' if color == 'blue' else 'blue'


def print_board(game, loc):
    print("board:")
    for x in range(game.board_width):
        for y in range(game.board_height):
            if loc == (x, y):
                print('*', end='')
                continue
            print(game.board[(x, y)], end='')
        print()
    print("end board")


debug = False


class AlphaBetaAgent(Agent):
    def __init__(self, role, max_depth=1, weak=False):
        super(AlphaBetaAgent, self).__init__(role)
        self.max_depth = max_depth
        self.weak = weak

    def choose_action(self, game):
        best_value = -math.inf
        best_action = None
        for act in game.legal_actions():
            if not has_neighbours(act, game):  
                continue
            value = self.alpha_beta_search(game, False, self.role,
                self.max_depth - 1, -math.inf, math.inf, act, 'red') 
            # print(act, "score: ", value)
            if best_value < value:
                best_value = max(best_value, value)
                best_action = act

        if best_action is None:  
            return random.choice(list(game.legal_actions()))

        # print('$' * 100)
        return best_action

    def alpha_beta_search(self, game, is_maximizing_player, player, depth, alpha, beta, action, color):
        
        assert isinstance(game, GoBangGame)

        game.take(action, player, show=debug, color=color)
        winner = game.winner()
        game.back(show=debug)
        if winner is not None or depth == 0:
            return self.heuristic(game, player, action)

        game.take(action, player, show=debug, color=color)

        if is_maximizing_player:
            best_value = -math.inf
            for act in game.legal_actions():
                if not has_neighbours(act, game):
                    continue
                value = self.alpha_beta_search(game, not is_maximizing_player, get_opponent(player),
                    depth - 1, alpha, beta, act, get_opponent_color(color))
                best_value = max(best_value, value)
                alpha = max(alpha, best_value)
                if alpha >= beta:
                    # print('prune')
                    break
        else:
            best_value = math.inf
            for act in game.legal_actions():
                if not has_neighbours(act, game):
                    continue
                value = self.alpha_beta_search(game, not is_maximizing_player, get_opponent(player),
                    depth - 1, alpha, beta, act, get_opponent_color(color))
                best_value = min(best_value, value)
                beta = min(beta, best_value)
                if alpha >= beta:
                    # print('prune')
                    break
        game.back(show=debug)
        return best_value

    def heuristic(self, game, me, action):
        
        if self.weak: 
            return self._heuristic(game, me, action)

        game.take(action, me, show=debug)  
        max_val_of_opponent = -math.inf
        for act in game.legal_actions():  
            if not has_neighbours(act, game):
                continue
            val = self._heuristic(game, get_opponent(me), act)  
            max_val_of_opponent = max(max_val_of_opponent, val)

        max_val_of_opponent = max(max_val_of_opponent, 0)
        game.back(show=debug)  

        
        return self._heuristic(game, me, action) - max_val_of_opponent

    def _heuristic(self, game, active_player, action):
        
        game.take(action, active_player, show=debug)  
        score = 0
        num_of_active2 = 0
        num_of_blocked2 = 0
        for k in range(4):  
            strides = range(-4, 4 + 1)
            line = get_line(*action, k, strides, game, active_player)
            s = 0

           
            if is_matching(five, line):
                s = 3000000
            elif is_matching(active4, line):
                s = 300000
            elif is_matching(blocked4A, line):
                s = 2500
            elif is_matching(blocked4B, line):
                s = 3000
            elif is_matching(blocked4C, line):
                s = 2600
            elif is_matching(active3, line[1:-1]):
                s = 3000
            elif is_matching(blocked3, line[1:-1]):
                s = 800
            elif is_matching(active2, line[2:-2]):
                num_of_active2 += 1
            elif is_matching(blocked2, line[2:-2]):
                num_of_blocked2 += 1

            score += s  
            # ss = [s for s in line]
            # ss[4] = '*'
            # line = ''.join(ss)
            # print(line, s)

        
        if num_of_active2 > 1:
            score += 3000
        if num_of_blocked2 > 1:
            score += 500

        # print('%' * 100)
        #
        # print_board(game, action)
        # print('me:', active_player)
        # print("score:", score)
        game.back(show=debug)  
        return score


if __name__ == '__main__':
    ai = AlphaBetaAgent(WHITE, 1)
