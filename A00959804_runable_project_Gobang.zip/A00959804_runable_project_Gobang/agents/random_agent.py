import random
from agents.agent import Agent


class RandomAgent(Agent):
    def __init__(self, role):
        super(RandomAgent, self).__init__(role)

    def choose_action(self, game):
        return random.choice(list(game.legal_actions()))
